function boolornumber(parametro) {
    if(typeof(parametro) === typeof(true)){
        parametro = !parametro
        console.log(parametro)
    }
    else if(typeof(parametro) === typeof(1)){
        parametro = parametro*-1
        console.log(parametro)
    }else{console.log("Booelano ou Número esperados, mas o parâmetro é do tipo", typeof(para))}
}

boolornumber(-12)