function multi(num1,num2) {
    var b = 0
    for(let i = 0; i < num1; i++){
        console.log(b)
        b = b+num2
    }
    if(num1 < 0 || num2 < 0 ){
        console.log("Números inválidos")
    }
    return b;
}

console.log(multi(4,2))