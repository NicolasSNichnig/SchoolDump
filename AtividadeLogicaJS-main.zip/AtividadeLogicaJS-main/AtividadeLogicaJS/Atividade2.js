function calculaIdade(idade){
    var dias = idade  * 365
    if(idade<=0){
        console.log('Erro, a idade está abaixo de 0')
    }else{console.log("Quem possue",idade,"já viveu",dias,'dias')}
}   
calculaIdade(18)