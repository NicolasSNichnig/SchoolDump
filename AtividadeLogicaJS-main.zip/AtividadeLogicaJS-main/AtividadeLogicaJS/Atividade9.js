function segundoMaior(arraynum){
    arraynum.sort();
    console.log(arraynum[arraynum.length-2])
}
segundoMaior([12,12,24,23])