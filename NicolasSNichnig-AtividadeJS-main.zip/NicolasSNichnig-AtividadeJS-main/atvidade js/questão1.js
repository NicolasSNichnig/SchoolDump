const sala5 = [
    {
        fileira: "K",
        numero: 1,
        disponivel: false
    },
    {
        fileira: "K",
        numero: 2,
        disponivel: true
    },
    {
        fileira: "K",
        numero: 3,
        disponivel: true
    },
    {
        fileira: "K",
        numero: 4,
        disponivel: false
    },
    {
        fileira: "K",
        numero: 5,
        disponivel: false
    },
]

if(sala5[0].disponivel === true){
    console.log("A cadeira" +sala5[0].numero,"está disponivel")
}

if(sala5[1].disponivel === true){
    console.log("A cadeira", sala5[1].numero,"está disponivel")
}

if(sala5[2].disponivel === true){
    console.log("A cadeira", sala5[2].numero,"está disponivel")
}

if(sala5[3].disponivel === true){
    console.log("A cadeira", sala5[3].numero,"está disponivel")
}

if(sala5[4].disponivel === true){
    console.log("A cadeira", sala5[4].numero,"está disponivel")}