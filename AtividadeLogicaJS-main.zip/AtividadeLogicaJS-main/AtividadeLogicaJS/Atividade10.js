var arrObj = [
    {
        nome: "Danilo", 
        notas: [10, 9, 8, 7]
    },
    {
        nome: "Roberta",
        notas: [10,10,10,10]
    },
    {
        nome: "Gabriel",
        notas: [6, 8, 7, 6]
    }
]

function media(arrObj){
    var media = []
    for (let index = 0; index < arrObj.length; index++) {
        var soma = 0
        for (nota of arrObj[index].notas){
            soma += nota
        }
        soma/arrObj[index].notas.length
        media.push(soma,arrObj[index].nome)
        }    
        media.sort();
        console.log("A aluna", media[media.length-1],"teve uma média de", media[media.length-4])
    }

media(arrObj)
