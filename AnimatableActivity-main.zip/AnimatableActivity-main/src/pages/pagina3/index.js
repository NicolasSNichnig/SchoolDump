import React from "react";
import * as Animatable from 'react-native-animatable';
import { View, Text, StyleSheet, TouchableHighlight, Image } from "react-native";

export default function Pagina3(){
    return(
      <Animatable.View style={styles.container} animation="bounceIn">
            <View style={styles.containerHeader}>
            <Image source={require('../../assets/indoali.jpeg')} style={styles.imageTitle}></Image>
            <Text style={styles.title}> Pagina 3</Text>
            </View>
        </Animatable.View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#38a69d'
    },  
    title: {
        fontSize: 20,
        marginTop: 28
      },  
      containerForm: {
        backgroundColor: '#fff',
        flex: 1,
        borderTopLeftRadius: 25,
        borderTopRightRadius: 25,
        paddingStart: '5%',
        paddingEnd: '5%'
      },
      containerHeader: {
        marginTop: '15%',
        marginBottom: '8%',  
      },
      imageTitle:{
        height: 150,
        width: 150,
        borderRadius: 360,
        alignSelf: 'center'
      },
      button: {
        backgroundColor: '#38A69D',
        borderRadius: 50,
        paddingVertical: 8,
        top: '5%',
        marginTop: 20,
        width: '60%',
        alignSelf: 'center',
        alignItems: 'center',
      },
      buttonText: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'bold'
      },
      title: {
        color: 'white',
        alignSelf: 'center',
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 12
      },
})