function compara(num1,num2){
    if(num1>num2){
        console.log(num1,"é maior que",num2)
    }else if(num1===num2){
        console.log(num1,"é igual a",num1)
    }
    else{console.log(num1,'Não é maior ou igual à',num2)}
}

compara(10,5)