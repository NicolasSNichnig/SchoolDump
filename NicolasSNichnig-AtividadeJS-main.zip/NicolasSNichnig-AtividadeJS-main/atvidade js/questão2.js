let macarronada = ["macarrão", "molho de tomate", "carne moída", "cebola", "alho"]
console.log(macarronada.length)