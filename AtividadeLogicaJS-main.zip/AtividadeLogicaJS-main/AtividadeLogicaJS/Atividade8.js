function somaArray(array){
    let soma = 0;
    for (let index = 0; index < array.length; index++) {
        soma += array[index]
    }
    console.log(soma)
}

somaArray([12,12,12])