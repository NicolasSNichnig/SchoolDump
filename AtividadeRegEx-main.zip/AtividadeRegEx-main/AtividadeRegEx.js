// 1° questão de Regex

// function trocaT(palavra) {
//     var str = palavra;
//     var n = str.replace(/[t]/ig, "7");
//     console.log(n);
// }

// trocaT("teste 12 Teste")

// 2° Questão de Regex

// function buscaPalavra(palavra) {
//     let re = new RegExp(/is/gi);
//     var fim = palavra.match(re)
//     var i = 0
//     for (const index in fim) {
//         i++
//     }
//     console.log("A palavra is se repete",i)
// }

// buscaPalavra("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", "is")

// 3° Questão de Regex

// function especifico(palavra) {
//     var regex = new RegExp(/^[t]/ig)
//     if (regex.test(palavra) == false){
//         console.log("Caracteres corretos")
//     }else{console.log("T não é um caractere disponivel")}
// }

// especifico('claudio')