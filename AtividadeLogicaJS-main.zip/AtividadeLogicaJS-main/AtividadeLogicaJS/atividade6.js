function array(palavra, repete){
    var b = []
    for (i = 0; i < repete; i++){
        b.push(palavra)
    }
    return b;
}

console.log(array("Danilo", 8))