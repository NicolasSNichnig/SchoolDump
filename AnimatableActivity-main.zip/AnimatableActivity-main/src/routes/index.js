import { createNativeStackNavigator } from '@react-navigation/native-stack'

import Welcome from '../pages/welcome'
import SignIn from '../pages/signin'
import Pagina1 from '../pages/pagina1';
import Pagina2 from '../pages/pagina2';
import Pagina3 from '../pages/pagina3';
import Pagina4 from '../pages/pagina4';
import Pagina5 from '../pages/pagina5';

const Stack = createNativeStackNavigator();

export default function Routes() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="Welcome" 
        component= { Welcome }
        options= { {headerShown: false} }
         />
      <Stack.Screen 
        name="SignIn" 
        component= { SignIn } 
        options= { {headerShown: false} }
        />
        <Stack.Screen
        name="Pagina1"
        component={Pagina1}
        options = {{headerShown: false, animation: 'fade_from_bottom'}}
        />
        <Stack.Screen
        name="Pagina2"
        component={Pagina2}
        options = {{headerShown: false, animation: 'fade_from_bottom'}}
        />
        <Stack.Screen
        name="Pagina3"
        component={Pagina3}
        options = {{headerShown: false, animation: 'fade_from_bottom'}}
        />
        <Stack.Screen
        name="Pagina4"
        component={Pagina4}
        options = {{headerShown: false, animation: 'fade_from_bottom'}}
        />
        <Stack.Screen
        name="Pagina5"
        component={Pagina5}
        options = {{headerShown: false, animation: 'fade_from_bottom'}}
        />
    </Stack.Navigator>
  )
}