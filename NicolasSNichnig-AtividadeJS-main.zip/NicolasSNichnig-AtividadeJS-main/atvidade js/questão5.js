const livrosCadastrados = [
    {
        nome: "Pequeno Principe",
        autor:"Antoine de Saint-Exupéry",
        id: "1"
    },

    {
        nome: "Harry Potter: A pedra filosofal",
        autor: "J.K Rowling",
        id: "2"
    },
    {
        nome: "Jogos Vorazes",
        autor: "Suzanne Marie Collins",
        id: "3"
    }

]

console.log(livrosCadastrados)