const cadastro = {

    email:'bananilsonfarofa@gmail.com',
    usuario: 'BananilsonFarofa',
    generoMasculino: true,
    idade: 20
    
    }    