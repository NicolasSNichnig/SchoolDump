function arrayFilter(parametro){
    var filtroNumero = parametro.filter(Number)
    console.log(filtroNumero)
}

arrayFilter(["adasda","adasdasw","adawd", 123, 2131, 12321])